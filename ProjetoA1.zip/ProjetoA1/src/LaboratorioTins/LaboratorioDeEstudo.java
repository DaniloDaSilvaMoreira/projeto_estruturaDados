package LaboratorioTins;
import java.util.ArrayList;
import java.util.List;

import Dados.*;

public class LaboratorioDeEstudo {
	
	public static void main(String[] args) {

		ArrayList<Atleta> atletas = new ArrayList<Atleta>();
		atletas.add(new Atleta("Mario", 115.6, 7));
		atletas.add(new Atleta("Joao", 90.5, 6));
		atletas.add(new Atleta("Pedro", 78.9, 1));
		atletas.add(new Atleta("Ana", 59.0, 3));
		atletas.add(new Atleta("Maria", 57.2, 9));
	

		System.out.println("Desordenado:\n");
		for (Atleta a : atletas) {
			System.out.println(a.getNome() + "| " + a.getPeso()+" Kg| " + "Nº Medalhas: " + a.getNumeroMedalhaOuro());
		}

		System.out.println("\n--------------------- Ordenado / PESO -----------------------------");
		LaboratorioDeEstudo.quickSortPeso(atletas, 0, atletas.size() - 1);

		for (Atleta a : atletas) {
			System.out.println(a.getNome() + "| " + a.getPeso() + " Kilos");
		}
		System.out.println("\n--------------------- Ordenado / Número de medalhas Ouro -----------------------------");
		LaboratorioDeEstudo.quickSortNumeroMedalha(atletas, 0, atletas.size() - 1);

		for (Atleta a : atletas) {
			System.out.println(a.getNome() + "| " + a.getNumeroMedalhaOuro() + " medalha(s)");
		}
		

	}
	
//////////////////////////////////////////////////////////////////////////////////////////
														//o índice da posição mais à esquerda da lista 
														//e o índice da posição mais à direita da lista.
	//"quickSortPeso" é usado para ordenar a lista por "Peso"
	//Usam recursão para particionar repetidamente o ArrayList 
	//e ordenar as partições até que todo o ArrayList esteja ordenado.
	public static void quickSortPeso(List<Atleta> atletas, int esquerda, int direita) {
		int pivo;
		if(direita > esquerda) {
			pivo = particionarPeso(atletas, esquerda, direita);
			quickSortPeso(atletas, esquerda, pivo - 1); 
            quickSortPeso(atletas, pivo + 1, direita);
		}	
	}
	
	//O método "particionarPeso" é usado para dividir a lista
	//O método compara o peso de cada atleta com o pivô e os reorganiza em ordem crescente.
	private static int particionarPeso(List<Atleta> atletas, int esquerda, int direita) {
		
		//pivô escolhido a partir do primeiro elemento da sub-lista.
		
		Atleta pivo = atletas.get(esquerda);
		
		//dois índices (i e j) para percorrer a lista de atletas.
		//índice i começa no segundo elemento da lista ( percorre da esquerda para direita )
		//índice j começa no último elemento da lista ( percorre da direita para esquerda )
		Integer i = esquerda + 1;
        Integer j = direita;
        
        while (i <= j) {
        	
        	//Se o peso do atleta no índice i for menor ou igual 
        	//ao pivô, o índice i é incrementado.
        	//compara o peso de cada Atleta com o pivô e os reordena em ordem crescente.
            if (atletas.get(i).getPeso() <= pivo.getPeso()) {
                i++;
            } else if (atletas.get(j).getPeso() > pivo.getPeso()) {
                j--;
            } else if (i <= j) {
            	//i e j se encontrarem, os elementos nas posições i e j são trocados de lugar. 
            	Atleta aux = atletas.get(i);
            	atletas.set(i, atletas.get(j));
                atletas.set(j, aux);
            }
        }
        Atleta aux = atletas.get(esquerda);
        atletas.set(esquerda, atletas.get(j));
        atletas.set(j, aux);
        
		return j;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////
	
public static void quickSortNumeroMedalha(List<Atleta> atletas, int esquerda, int direita) {
		int pivo;
		
		if(direita > esquerda) {
			pivo = particionarNumeroMedalha(atletas, esquerda, direita);
			quickSortNumeroMedalha(atletas, esquerda, pivo - 1); 
			quickSortNumeroMedalha(atletas, pivo + 1, direita);
		}

}

private static int particionarNumeroMedalha(List<Atleta> atletas, int esquerda, int direita) {
	Atleta pivo = atletas.get(esquerda);

	Integer i = esquerda + 1;
	Integer j = direita;
	
	while (i <= j) {
		if (atletas.get(i).getNumeroMedalhaOuro() <= pivo.getNumeroMedalhaOuro()) {
			i++;
		} else if (atletas.get(j).getNumeroMedalhaOuro() > pivo.getNumeroMedalhaOuro()) {
			j--;
		} else if (i <= j) {
			Atleta aux = atletas.get(i);
			atletas.set(i, atletas.get(j));
			atletas.set(j, aux);
				}
		}
		Atleta aux = atletas.get(esquerda);
		atletas.set(esquerda, atletas.get(j));
		atletas.set(j, aux);
	
		return j;
	}


}
