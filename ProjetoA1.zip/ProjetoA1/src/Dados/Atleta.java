package Dados;

public class Atleta {

		private String nome;
		private Double peso;
		private Integer numeroMedalhaOuro;
		
		public Atleta(String nome, Double peso, Integer numeroMedalhaOuro) {
			this.nome = nome;
			this.peso = peso;
			this.numeroMedalhaOuro = numeroMedalhaOuro;
		}
		
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public Double getPeso() {
			return peso;
		}

		public void setPeso(Double peso) {
			this.peso = peso;
		}

		public Integer getNumeroMedalhaOuro() {
			return numeroMedalhaOuro;
		}

		public void setNumeroMedalhaOuro(Integer numeroMedalhaOuro) {
			this.numeroMedalhaOuro = numeroMedalhaOuro;
		}
}
