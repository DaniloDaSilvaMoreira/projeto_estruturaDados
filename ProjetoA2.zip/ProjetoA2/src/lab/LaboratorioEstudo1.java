package lab;

import java.util.List;
import unitins.*;

public class LaboratorioEstudo1 {
	
	    public static void main(String[] args) {
	    	
	        MapaConexoesAereas mapaConexoes = new MapaConexoesAereas();

	        // Adicionar voos ao mapa de conexões
	        
	        mapaConexoes.adicionarVoo("São Paulo", "Rio de Janeiro", "06:00","200km", true);
	        mapaConexoes.adicionarVoo("São Paulo", "Belo Horizonte", "06:30","700km", false);
	        mapaConexoes.adicionarVoo("Rio de Janeiro", "Brasília", "07:40","800km", true);
	        
	        
	        mapaConexoes.adicionarVoo("São Paulo", "Salvador", "14:20","1200km", true);
	        /*mapaConexoes.adicionarVoo("Rio de Janeiro", "Tocantins", "16:00","1800km", true);
	        mapaConexoes.adicionarVoo("Rio de Janeiro", "Paraná", "18:00","1500km", true);
	        mapaConexoes.adicionarVoo("Belo Horizonte", "Salvador", "14:20","1200km", false);*/
	        
	       
	        // Obter voos possíveis a partir de uma cidade de origem
	        
	        String cidadeOrigem = "São Paulo";
	        List<NodeVoo> voosPossiveis = mapaConexoes.obterVoosPossiveis(cidadeOrigem);

	        // Exibir voos possíveis
	        if (voosPossiveis.isEmpty()) {
	        	System.out.println("---------------------------------------------------------");
	            System.out.println("Não há voos disponíveis a partir de " + cidadeOrigem);
	        } else {
	        	System.out.println("---------------------------------------------------------");
	        	System.out.println(" ");
	            System.out.println("Voos disponíveis a partir de (" + cidadeOrigem + "):");
	            for (NodeVoo voo : voosPossiveis) {
	                System.out.println("Destino: " + voo.getDestino() + ", Horário: " + voo.getHorario() + " | Km: "+voo.getDistancia()+ ", Disponível: " + voo.isConfirmado());
	            }
	        }
	        
	        /////////////////////////////////// TESTES /////////////////////////////////////////////////
	        
	        NodeVoo voo1 = new NodeVoo("São Paulo", "Rio de Janeiro", "06:00","200km", true);
	        voo1.adicionarVooRealizado(mapaConexoes, "São Paulo","Rio de Janeiro","06:00");
	        
	        NodeVoo voo2 = new NodeVoo("São Paulo", "Belo Horizonte", "06:30","700km", true);
	        voo2.adicionarVooRealizado(mapaConexoes, "São Paulo","Belo Horizonte","06:30");
	        
	        NodeVoo voo3 = new NodeVoo("Rio de Janeiro", "Brasília", "07:40","800km", true);
	        voo3.adicionarVooRealizado(mapaConexoes, "Rio de Janeiro","Brasília","08:40");
	        
	        NodeVoo voo4 = new NodeVoo("São Paulo", "Salvador", "14:20","1200km", true);
	        voo4.adicionarVooRealizado(mapaConexoes, "São Paulo","Salvador","14:20");
	        
	        
	        /*for (NodeVoo voo : voosPossiveis) { 
	        if (voo.isConfirmado()==false) {
	        	System.out.println("---------------------------CANCELADO------------------------------");
	        	System.out.println(" ");
                System.out.println("Destino: " + voo.getDestino() + ", Horário: " + voo.getHorario() + ", Cancelado: " + voo.isConfirmado());
            	}
	        }*/  
	}
}

