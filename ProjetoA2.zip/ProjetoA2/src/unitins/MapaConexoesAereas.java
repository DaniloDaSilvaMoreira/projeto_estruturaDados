package unitins;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapaConexoesAereas {
	
    private Map<String, List<NodeVoo>> mapaVoos;

    public MapaConexoesAereas() {
        mapaVoos = new HashMap<>();
    }

    public void adicionarVoo(String origem, String destino, String horario,String distancia, boolean confirmado) {
    	
    	NodeVoo voo = new NodeVoo(origem, destino, horario,distancia, confirmado);

        if (mapaVoos.containsKey(origem)) {
            mapaVoos.get(origem).add(voo);
        } else {
            List<NodeVoo> voos = new ArrayList<>();
            voos.add(voo);
            mapaVoos.put(origem, voos);
        }
        
        System.out.println("--------------------CONEXÕES AÉREAS-------------------------------------");
        System.out.println(" ");
        System.out.println("Origem: "+origem+ "| Destino: "+destino+ "| Horário: "+horario+"| Km: "+distancia+" , disponível: "+confirmado);
    }
    
    

    public List<NodeVoo> obterVoosPossiveis(String origem) {
    	
        if (mapaVoos.containsKey(origem)) {
            return mapaVoos.get(origem);
        } else {
            return new ArrayList<>();
        }
    }  
}
