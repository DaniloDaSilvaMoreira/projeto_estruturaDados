package unitins;

import java.util.List;

public class NodeVoo {
	
    private String origem;
    private String destino;
    private String horario;
    private String distancia;
    private boolean confirmado;

    public NodeVoo(String origem, String destino, String horario, String distancia,boolean confirmado) {
    	
        this.origem = origem;
        this.destino = destino;
        this.horario = horario;
        this.distancia = distancia;
        this.confirmado = confirmado;
    }
    
    public void adicionarVooRealizado(MapaConexoesAereas mapaConexoes, String origem, String destino, String horario) {
        List<NodeVoo> voosPossiveis = mapaConexoes.obterVoosPossiveis(origem);
        for (NodeVoo voo : voosPossiveis) {
            if (voo.getDestino().equals(destino) && voo.getHorario().equals(horario) && voo.isConfirmado() == true) {
            	System.out.println("---------------------------------------------------------");
            	System.out.println(" ");
                System.out.println("Voo realizado: Origem: " + origem + ", Destino: " + destino + ", Km: "+distancia+", Horário: " + horario);
                return;
            }
        }
        System.out.println("---------------------------------------------------------");
        System.out.println(" ");
        System.out.println("Voo não encontrado: Origem: " + origem + ", Destino: " + destino + ", Horário: " + horario);
    }
    
    public NodeVoo(String origem) {
    	
        this.origem = origem;
    }

    public String getOrigem() {
        return origem;
    }

    public String getDestino() {
        return destino;
    }

    public String getHorario() {
        return horario;
    }
    public String getDistancia() {
        return distancia;
    }
    
    public boolean isConfirmado() {
        return confirmado;
    }
    
    public void isConfirmado(boolean confirmado) {
    	this.confirmado = confirmado;
    }
    
}

